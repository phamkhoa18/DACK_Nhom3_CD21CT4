import javax.swing.text.Style;

public class Login {
    public  boolean Login(
            String email ,
            String password
    ) {
            Boolean flag = true ;
            if(checkstring(email) || checkstring(password)){
                System.out.println("Vui lòng không để trống");
                flag = false ;
                return  false ;
            }
            if(flag == true) {
                System.out.println("Đăng nhập thành công");
                return  true ;
            }
            return  false ;
    } ;

    //    Kiểm tra chuỗi có rỗng hay không
    static boolean checkstring(String string){
        return string==null || string.isEmpty();
    }
    //    Validate Email
    public static boolean validateemail(String email) {
        Boolean result = email.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
        if(result == false) {
            System.out.println("Vui lòng nhập đúng định dạng Email");
        } else  {
            System.out.println("Nhập đúng định dạng ");
        }
        return result;
    };

    public  static  boolean validatePassword(String password) {
        if(password.length() < 5 || password.length() > 20) {
            System.out.println("Password tối thiểu là 5 ký tự và tối đa 20 ký tự");
            return  false ;
        } else  {
            System.out.println("Password nhập đúng định dạng");
            return  true ;
        }
    }
}
