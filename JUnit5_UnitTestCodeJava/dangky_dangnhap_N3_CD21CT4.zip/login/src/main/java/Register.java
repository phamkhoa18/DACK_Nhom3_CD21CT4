import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class Register {
    public boolean Register(
            String lastname,
            String firstname,
            Boolean sex,
            String year,
            String email,
            String pass)
    {
        Boolean flag  = true ;
        if(checkstring(lastname) || checkstring(firstname) || checkstring(email) || checkstring(pass) || checkstring(year)) {
            flag = false ;
            System.out.println("Fill in all the information");
            return  false ;
        }

        if(lastname.length() < 3 || lastname.length() > 20) {
            System.out.println("lastname minimum 3 characters and not more than 20 characters");
            flag = false ;
            return  false ;
        }
        if(firstname.length() < 3 || firstname.length() > 20) {
            System.out.println("firstname minimum 3 characters and not more than 20 characters");
            flag = false ;
            return  false ;
        }
        if(pass.length() <= 5 || pass.length() > 20) {
            System.out.println("password minimum 5 characters and not more than 20 characters");
            flag = false ;
            return  false ;
        } else  {
            System.out.println("password success !");
        }

        if(sex == null) {
            System.out.println("Please select gender");
            return  false ;
        }

        if(flag == true) {
            return  true ;
        }

        return false;
    };

    //    Kiểm tra chuỗi có rỗng hay không
    static boolean checkstring(String string){
        return string==null || string.isEmpty();
    }
    //    Validate Email
    public static boolean validateemail(String email) {
        return email.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
    };

    public  static  boolean validateDate(String year) {
        String regex = "^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(year);
        if(matcher.matches() == false) {
            System.out.println("Không đúng định dạng");
        } else  {
            System.out.println("Đúng định dạng (tháng / ngày / năm)");
        }
        return  matcher.matches();
    };

};

