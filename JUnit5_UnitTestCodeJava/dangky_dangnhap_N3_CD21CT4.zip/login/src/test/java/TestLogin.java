import org.junit.Test;

import static org.junit.jupiter.api.Assertions.* ;
public class TestLogin {
    Login h1 = new Login() ;

    //    Test lỗi email rỗng
    @Test
    public  void  testLogin1() {
        assertEquals(false , h1.Login("","123456"));
    }
    //    Test lỗi password rỗng
    @Test
    public  void  testLogin2() {
        assertEquals(false , h1.Login("phamkhoa123gmail.com",""));
    }
    //    Test lỗi email sai định dạng
    @Test
    public  void  testLogin3() {
        assertFalse(h1.validateemail("phamkhoa123gmail.com"));
    }
    //    Test lỗi email đúng định dạng
    @Test
    public  void  testLogin4() {
        assertTrue(h1.validateemail("phamkhoa123@gmail.com"));
    }
    //    Test lỗi password nhỏ hơn 5 ký tự
    @Test
    public  void  testLogin5() {
        assertFalse(h1.validatePassword("1234"));
    }
    //    Test lỗi password lớn hơn 20 ký tự
    @Test
    public  void  testLogin6() {
        assertFalse(h1.validatePassword("000000000000000000000000000000"));
    }
    @Test
//    đăng nhập thành công
    public  void testLogin7() {
        assertEquals(true , h1.Login("phamkhoa123@gmail.com","1234567"));
    }
    @Test
//    đăng nhập thất bại
    public  void testLogin8() {
        assertEquals(false , h1.Login("phamkhoa123@gmail.com",""));
    }
}
