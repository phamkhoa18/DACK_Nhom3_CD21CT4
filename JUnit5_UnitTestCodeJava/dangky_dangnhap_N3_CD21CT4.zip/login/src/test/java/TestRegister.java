import org.junit.Test;

import static org.junit.jupiter.api.Assertions.* ;
public class TestRegister {
    Register h1 = new Register() ;

//    Test lỗi lastname = ''
    @Test
    public  void  testRegister1() {
        assertEquals(false , h1.Register("","khoa",false,"30/09/2003","phamkhoa@gmail.com","12345678"),"Validate Error");

    }
//    Test lỗi lastname = 1 ( tối thiểu )
    @Test
    public  void  testRegister2() {
        assertEquals(false , h1.Register("1","khoa",false,"30/09/2003","phamkhoa@gmail.com","12345678"),"Validate Error");
    }
//    Test lỗi lastname = phamkhoa33322222111111111 ( tối đa )
    @Test
    public  void  testRegister3() {
        assertEquals(false , h1.Register("phamkhoa33322222111111111","khoa",false,"30/09/2003","phamkhoa@gmail.com","12345678"),"Validate Error");
    }

    //    Test lỗi firstname = ''
    @Test
    public  void  testRegister4() {
        assertEquals(false , h1.Register("pham","",false,"30/09/2003","phamkhoa@gmail.com","12345678"),"Validate Error");
    }

    //    Test lỗi firstname = '1'
    @Test
    public  void  testRegister5() {
        assertEquals(false , h1.Register("pham","1",false,"30/09/2003","phamkhoa@gmail.com","12345678"),"Validate Error");
    }
    //    Test lỗi firstname = phamkhoa333333333333333333 ( tối đa )
    @Test
    public  void  testRegister6() {
        assertEquals(false , h1.Register("pham","phamkhoa333333333333333333",false,"30/09/2003","phamkhoa@gmail.com","12345678"),"Validate Error");
    }
    //    Test lỗi sex = null
    @Test
    public  void  testRegister7() {
        assertEquals(false , h1.Register("pham","khoa",null,"30/09/2003","phamkhoa@gmail.com","12345678"),"Validate Error");
    }
    //    Test Email trường hợp đúng
    @Test
    public  void  testRegister8() {
        assertTrue(h1.validateemail("phamkhoa123@gmail.com"));
    }
    //    Test Email trường hợp sai định dạng
    @Test
    public  void  testRegister9() {
        assertFalse(h1.validateemail("phamkhoa123gmail.com"),"Validate Email");
    }
    //    Test Year Đúng định dạng (tháng / ngày / năm)
    @Test
    public  void  testRegister10() {
        assertTrue(h1.validateDate("12/30/1990"));
    }
    //    Test Year Sai định dạng (tháng / ngày / năm)
    @Test
    public  void  testRegister11() {
        assertFalse(h1.validateDate("05/02/199"));
    }
    //    Test Password đúng yêu cầu
    @Test
    public  void  testRegister12() {
        assertEquals(true , h1.Register("pham","khoa",false,"30/09/2003","phamkhoa@gmail.com","123456"),"Validate Error");
    }
    //    Test Password nhỏ hơn 5 ký tự
    @Test
    public  void  testRegister13() {
        assertEquals(false , h1.Register("pham","khoa",false,"30/09/2003","phamkhoa@gmail.com","1234"),"Validate Error");
    }
    //    Test Password nhỏ lớn hơn 20 ký tự
    @Test
    public  void  testRegister14() {
        assertEquals(false , h1.Register("pham","khoa",false,"30/09/2003","phamkhoa@gmail.com","000000000000000000000"),"Validate Error");
    }


}
