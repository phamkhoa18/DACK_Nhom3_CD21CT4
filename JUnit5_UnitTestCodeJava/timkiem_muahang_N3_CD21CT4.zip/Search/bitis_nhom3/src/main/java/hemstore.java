import java.util.Objects;

public class hemstore {
//đăng ký
    public String HoTen(String HoTen)
    {
        if(HoTen == "" || HoTen.length() > 12)
            return "Huỳnh Trọng Phúc Phú Như";
        else
            return HoTen;
    }
    public String Sodienthoai(String Sodienthoai)
    {
        if(Sodienthoai == "" || Sodienthoai.length() >=10 && Sodienthoai.length()<=11)
            return "0909102092";
        else
            return Sodienthoai;
    }
    public String Email(String Email)
    {
       if(Email==""|| Email.length()>10)
            return  "nhu@gmail.com";
       else
        return Email;
    }
    public String Pass(String Pass)
    {
        if(Pass == "" || Pass.length() < 8 || Pass.length() > 32)
            return "nhu123123";
        else
            return Pass;
    }
//đăng nhập
    public String Ten_Dang_Nhap(String Ten_Dang_Nhap)
    {
        if(Ten_Dang_Nhap == "" || Ten_Dang_Nhap.length() > 12)
            return "";
        else
            return Ten_Dang_Nhap;
    }

    public String Emaildangnhap(String Email)
    {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        if(Email.matches(EMAIL_PATTERN))
            return  Email;
        else
            return  "";

    }
    public String fullname(String fullname)
    {
        if(fullname == "" || fullname.length() < 8 || fullname.length() > 32)
            return "";
        else
            return fullname;
    }
    public String Email1(String Email)
    {
        if(Email == "")
            return "";

        return Email;
    }
    public String Password(String Password)
    {
        if(Password == "" || Password.length() < 8 || Password.length() > 32)
            return "";
        else
            return Password;
    }



}