import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class Testhemstore {
    hemstore a = new hemstore();
    @Test
    public void TestcasePremium1()
    {
        assertEquals("Vui long nhap dung thong tin",a.HoTen(""),"Huỳnh Trọng Phúc Phú Như");
    }
    @Test
    public void TestcasePremium2()
    {

        assertEquals("Vui long nhap dung thong tin",a.Sodienthoai("0909102092"),"0909102092");
    }
    @Test
    public void TestcasePremium3()
    {

        assertEquals("Vui long nhap dung thong tin",a.Email(""),"nhu@gmail.com");
    }
    @Test
    public void TestcasePremium4()
    {

        assertEquals("Vui long nhap dung thong tin",a.Password(""),"nhu123123");
    }
}
